/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{html,ts}",
  ],
  theme: {
    extend: {
      colors: {
        'web-blue': '#0353cc',
        'web-black': '#020202',
        'text-gray': '#8c8c8d',
        'gray-bg': '#f3f8fe',
        'tomato-red': '#ff5757'
      },
      fontFamily: {
        poppins: ['Poppins', "sans-serif"],
        titan: ['Titan One', "sans-serif"]
      }
    },
  },
  plugins: [],
}

